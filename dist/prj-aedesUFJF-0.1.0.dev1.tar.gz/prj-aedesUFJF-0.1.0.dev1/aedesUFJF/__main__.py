from aedesUFJF import aedesPrediction

aedesPrediction.main()
