from aedesUFJF import AedesPopulation, aedesPrediction, Clustering, Forecast, Model, Mosquito, Plot
print("Hello world !")
