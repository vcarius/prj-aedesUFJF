from aedesUFJF import AedesPopulation, aedesPrediction, Clustering, Forecast, Model, Mosquito, Plot, GetData
print("Hello world !")
