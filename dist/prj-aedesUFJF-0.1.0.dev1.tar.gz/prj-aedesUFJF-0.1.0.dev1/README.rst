README
======

This is a developer version of the Aedes aegypti dispersion model

===========
INTALLATION
===========
pip install prj-aedesUFJF
pip install git+https://github.com/matplotlib/basemap.git
