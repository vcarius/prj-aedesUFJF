README
======

This is a developer version of the Aedes aegypti dispersion model
